The Kinect Class files need to be used after setting up a WPF application in VS2010.
The Kinect SDK needs to be installed in the client machine and the project needs to referance 
the correct locations for the DLLs. Then the program should compile and run.

The php scrips need a host server with access to a mysql database, see report for table discription. 

The SL scrips embed directly into the prim objects in SL and will attempt to contact host server when created. 
The SmartObject script is the main script.
The GameCondition is a trimed version if the SmartObject that just changes color and nothing else.  