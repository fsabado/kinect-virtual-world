﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;
using Microsoft.Research.Kinect.Nui;

namespace WpfApplication_KinectProjectToPHPandSL
{
    
    /// <summary>
    /// Christian Williams 
    /// University of Arkansas 010537189
    /// ccw005@uark.edu
    /// 
    /// This class establishes a new game for a user including setup of objects
    /// controls the game flow and handles interpreting user intentions 
    /// based on the gestures from a user. 
    /// </summary>
    class KinectModelGame
    {
        /// <summary>
        /// The types of states that the game can be in. 
        /// </summary>
        enum GameCommandState
        {
            Stop, Exit, Reset, Color, Size, Shape, Rotation, Check
        }

        /// <summary>
        /// Used to contain the SlColor scheme
        /// </summary>
        public struct  SlColor
        {

            public double Red;
            public double Green;
            public double Blue;

            public SlColor(double red, double green, double blue)
            {
                this.Red = red;
                this.Green = green;
                this.Blue = blue;               
            }
        }
        // set the desired specific SL colors
        SlColor _white = new SlColor(1.0, 1.0, 1.0);
        SlColor _grey = new SlColor(0.5, 0.5, 0.5);
        SlColor _black = new SlColor(0.0, 0.0, 0.0);
        SlColor _red = new SlColor(1.0, 0.0, 0.0);
        SlColor _green = new SlColor(0.0, 1.0, 0.0);
        SlColor _blue = new SlColor(0.0, 0.0, 1.0);
        SlColor _yellow = new SlColor(1.0, 1.0, 0.0);
        SlColor _cyan = new SlColor(0.0, 1.0, 1.0);
        SlColor _magenta = new SlColor(1.0, 0.0, 1.0);

        private SlColor[] _slColorArray;

        
        /// <summary>
        /// The available shapes in easy to reference and cycle though form
        /// </summary>
        List<string> _primShapes = new List<string>(
            new string[] { "box", "cylinder", "prism", "sphere", "torus", "ring", "tube" });
                
        // location for the prims that the game will use to display to the user.
        private const String _phpUrl 
            = "http://turing.csce.uark.edu/~ccw005/KinectSLServer.php";
        // user game piece
        private ModelPrim _userPrim;
        // computer game piece
        private ModelPrim _gamePrim;
        // computer win condition game piece
        private ModelPrim _winCondPrim;
        // communication object to and from SL and PHP server
        private KinectHttpRequest _gameRequest;
        // random prim http request object no threading issues
        private KinectHttpRequest _randomReq;
        // win prim request url
        private KinectHttpRequest _winConReq;

        // easy to reference the game pieces 
        private ModelPrim[] _primArray;
        // the current game state global variable
        private GameCommandState GameState { get; set; }
        // wpf application widow reference 
        private MainWindow _mw;
        // timer for rotation of the prim
        RotationTimer _rotationTimer;
        // counter for input frequency
        int cycleCount;
        


        /// <summary>
        /// Establish the game from the WPF window. 
        /// </summary>
        /// <param name="mw"></param>
        public KinectModelGame(MainWindow mw)
        {
            this._gameRequest = new KinectHttpRequest(_phpUrl);
            this._userPrim = new ModelPrim();
            this._gamePrim = new ModelPrim();
            this._winCondPrim = new ModelPrim();
            this._slColorArray = new SlColor[] { this._white, this._grey, this._black, this._red, this._green, this._blue, this._yellow, this._cyan, this._magenta };
            this._primArray = 
                new ModelPrim[] { this._userPrim, this._gamePrim, this._winCondPrim};
            this.GameState = GameCommandState.Stop;
            this._mw = mw;
            StartGame();
            RestartGame();
            // establish a RotationTimer and its handler in this class
            this._rotationTimer = new RotationTimer();
            this._rotationTimer.RotateTime += this.RotationTimerHandler;
        }

        /// <summary>
        /// Get the current game objects from the server and store them 
        /// for game communication.  
        /// </summary>
        public void StartGame()
        {
            Dictionary<String, String> primKeyValuePair;
            // get the list of prims and initialize the user/game prims
            try
            {
                primKeyValuePair = this._gameRequest.GetPrimListPHP();
                int numOfObjects = 0;
                foreach (var key in primKeyValuePair.Keys)
                {
                    if (key == "GameObject")
                    {
                        this._primArray[numOfObjects].PrimName = key;
                        this._primArray[numOfObjects].PrimUrl = primKeyValuePair[key];
                        Debug.WriteLine(this._primArray[numOfObjects].ToString());
                    }

                    if (key == "UserObject")
                    {
                        this._primArray[numOfObjects].PrimName = key;
                        this._primArray[numOfObjects].PrimUrl = primKeyValuePair[key];
                        Debug.WriteLine(this._primArray[numOfObjects].ToString());

                    }

                    if (key == "GameCondition")
                    {
                        this._primArray[numOfObjects].PrimName = key;
                        this._primArray[numOfObjects].PrimUrl = primKeyValuePair[key];
                        Debug.WriteLine(this._primArray[numOfObjects].ToString());
                    }
                    numOfObjects++;
                }
            }
            catch (System.Exception ex)
            {
                _mw.Close();
            }                        
        }        

        /// <summary>
        /// Set the state of the User prim at these default starting values
        /// </summary>
        public void DefaultUserPrim()
        {
          // set the default state of the user prim
           ChangeColor(this._userPrim, 1.0, 1.0, 1.0);
           ChangeShape(this._userPrim, this._primShapes.ElementAt(0));
           ChangeSize(this._userPrim, 1.0, 1.0, 1.0);
           
        }

        /// <summary>
        /// Send the random generated parameters to the prim. 
        /// </summary>
        public void RandomGamePrim()
        {
            Random randomInt = new Random();
            
            int randColorInt = randomInt.Next(0, 9);
            // set the game prim to the new color //double.Parse(String.Format("{0:F1}", randomInt.NextDouble()));
            this._gamePrim.PrimColorRed =    (double)this._slColorArray[randColorInt].Red; 
            this._gamePrim.PrimColorGreen = (double)this._slColorArray[randColorInt].Green; 
            this._gamePrim.PrimColorBlue = (double)this._slColorArray[randColorInt].Blue ;   
            
            // execute the change of state and update to SL
            _randomReq = new KinectHttpRequest(this._gamePrim.PrimUrl);
            _randomReq.ChangeColorSL(this._gamePrim.PrimColorRed
                , this._gamePrim.PrimColorGreen
                , this._gamePrim.PrimColorBlue);                
            
            // set the game prim to the new shape
            this._gamePrim.PrimShape = this._primShapes.ElementAt(randomInt.Next(0,7));
            _randomReq.ChangeShapeSL(this._gamePrim.PrimShape);

            // set the game prim to the new size range 0.0 - 4.0; .1 increments; 0.0 = 0.1 by property setting
            this._gamePrim.PrimSizeX = double.Parse(String.Format("{0:F1}", randomInt.NextDouble() * 4.0));
            this._gamePrim.PrimSizeY = double.Parse(String.Format("{0:F1}", randomInt.NextDouble() * 4.0));
            this._gamePrim.PrimSizeZ = double.Parse(String.Format("{0:F1}", randomInt.NextDouble() * 4.0));
            _randomReq.ChangeSizeSL(this._gamePrim.PrimSizeX, this._gamePrim.PrimSizeY, 1.0); //this._gamePrim.PrimSizeZ);
            

        }

        /// <summary>
        /// Used to define the victory condition
        /// </summary>
        public void ComparePrims()
        {
            this._winConReq = new KinectHttpRequest(this._winCondPrim.PrimUrl);
            // compare the two prims to see if they are the same and let the user know. 
            if (this._gamePrim.Equals(this._userPrim))
                this._winConReq.ChangeColorSL(this._green.Red, this._green.Green, this._green.Blue);
            else
                this._winConReq.ChangeColorSL(this._red.Red, this._red.Green, this._red.Blue);
           
        }
        
        /// <summary>
        /// Used to restart the game by resetting the game values. 
        /// </summary>
        public void RestartGame()
        {           
            // reset gamePrim
            RandomGamePrim();
            // reset userPrim
            DefaultUserPrim();
            // reset the win condition object.
            ComparePrims();
        }

        /// <summary>
        ///  This method controls the state of the game by way of detecting audio events
        /// </summary>
        public void GameUserState(double confidence , String recognizeText)
        {
            Debug.WriteLine("Recognized: {0} {1}", confidence, recognizeText);            
            switch (recognizeText.ToUpper())
            {
                case "STOP":
                    this.GameState = GameCommandState.Stop;
                    Debug.WriteLine("Case: stop " + recognizeText.ToUpper());
                    break;
                case "RESET":
                    this.GameState = GameCommandState.Reset;
                    Debug.WriteLine("Case: reset " + recognizeText.ToUpper());
                    RestartGame();
                    this.GameState = GameCommandState.Stop;                    
                    break;
                case "COLOR":
                    this.GameState = GameCommandState.Color;
                    Debug.WriteLine("Case: color " + recognizeText.ToUpper());
                    break;
                case "SIZE":
                    this.GameState = GameCommandState.Size;
                    Debug.WriteLine("Case: size " + recognizeText.ToUpper());
                    break;
                case "SHAPE":
                    this.GameState = GameCommandState.Shape;
                    Debug.WriteLine("Case: shape " + recognizeText.ToUpper());
                    break;
                case "ROTATION":
                    this.GameState = GameCommandState.Rotation;
                    Debug.WriteLine("Case: rotation " + recognizeText.ToUpper());
                    this._rotationTimer.ToggleTimer();
                    this.GameState = GameCommandState.Stop;
                    break;                
                case "CHECK":
                    this.GameState = GameCommandState.Check;
                    Debug.WriteLine("Case: check " + recognizeText.ToUpper());
                    ComparePrims();
                    this.GameState = GameCommandState.Stop;
                    break;
                default:                    
                    break;
            }
            if (this.GameState == GameCommandState.Shape)
            {
                InterpretGestureShape(confidence, recognizeText);
            }

            if (this.GameState == GameCommandState.Color)
            {
                InterpretGestureColor(confidence, recognizeText);
            }

        }
        
        /// <summary>
        /// Used to direct the Kinect data to correct SL action.
        /// </summary>
        /// <param name="command"></param>
        /// <param name="kinectXYZ"></param>
        public void CommandSLObject(SkeletonData skeleton)
        {
            switch (this.GameState)
            {
                case GameCommandState.Color:                    
                        
                        break;                    
                case GameCommandState.Size:
                        InterpretGestureSize(skeleton);
                        break;
                case GameCommandState.Shape:
                        
                        break;
                case GameCommandState.Rotation:
                        InterpretGestureRotation();
                        break;                              
                case GameCommandState.Reset:
                        RestartGame();
                        this.GameState = GameCommandState.Stop;
                        break;
                case GameCommandState.Check:
                        ComparePrims();
                        this.GameState = GameCommandState.Stop;
                        break;
                default:
                    // no operation
                    break;
            }
        }

        /// <summary>
        /// Update the prim and transmit to SL
        /// note this method updates both the object and the SL representation
        /// </summary>
        /// <param name="prim"></param>
        /// <param name="data"></param>
        public void ChangeColor(ModelPrim prim, double red, double green, double blue)
        {
            // update the state of the prim to the new color
            prim.PrimColorRed = red;
            prim.PrimColorGreen = green;
            prim.PrimColorBlue = blue;
            // make sure to contact the correct prim
            _gameRequest.Url = prim.PrimUrl;
            // now command the prim to change its color in SL
            this._gameRequest.ChangeColorSL(prim.PrimColorRed
                ,prim.PrimColorGreen
                ,prim.PrimColorBlue); 
        }

        /// <summary>
        /// Update the prim size and transmit to SL
        /// note this method updates both the object and the SL representation
        /// </summary>
        /// <param name="prim"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        public void ChangeSize(ModelPrim prim, double x, double y, double z)
        {
            // set the prim for game tracking for application from kinect
            prim.PrimSizeX = x;
            prim.PrimSizeY = y;
            prim.PrimSizeZ = 1.0;// z;

            // make sure the right prim is selected in SL
            _gameRequest.Url = prim.PrimUrl;

            // command the prim in SL
            this._gameRequest.ChangeSizeSL(prim.PrimSizeX
                ,prim.PrimSizeY
                ,prim.PrimSizeZ);
        }

        /// <summary>
        /// Update the prim shape and transmit to SL
        /// note this method updates both the object and the SL representation
        /// </summary>
        /// <param name="prim"></param>
        /// <param name="data"></param>
        public void ChangeShape(ModelPrim prim, String data)
        {
            Debug.WriteLine(prim.PrimName + " " + data + "Here");
            prim.PrimShape = data;
            _gameRequest.Url = prim.PrimUrl;
            this._gameRequest.ChangeShapeSL(data);
        }

        /// <summary>
        /// Update the prims rotation and transmit to SL
        /// note this method updates both the object and the SL representation
        /// </summary>
        /// <param name="prim"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        public void ChangeRotation(ModelPrim prim,double x, double y, double z )
        {
            // set the prim for game tracking for application from kinect
            prim.PrimRotationX = x;
            prim.PrimRotationY = y;
            prim.PrimRotationZ = z;

            // make sure the right prim is selected in SL
            _gameRequest.Url = prim.PrimUrl;

            // command the prim in SL
            this._gameRequest.ChangeRotationSL(prim.PrimRotationX
                ,prim.PrimRotationY
                ,prim.PrimRotationZ);
        }

        /// <summary>
        /// Used to determine what color the user is indicating and to change it to 
        /// that color. 
        /// </summary>
        /// <param name="confidence"></param>
        /// <param name="recognizeText"></param>
        public void InterpretGestureColor(double confidence, String recognizeText)
        {
            SlColor color;
            switch (recognizeText.ToUpper())
            {
                case "WHITE":
                    Debug.WriteLine("Case: white " + recognizeText.ToUpper());
                    color = this._white;
                    ChangeColor(this._userPrim,color.Red,color.Green, color.Blue );
                    break;
                case "GREY":
                    Debug.WriteLine("Case:  grey " + recognizeText.ToUpper());
                    color = this._grey;
                    ChangeColor(this._userPrim,color.Red,color.Green, color.Blue );
                    break;
                case "BLACK":
                    Debug.WriteLine("Case: black " + recognizeText.ToUpper());
                    color = this._black;
                    ChangeColor(this._userPrim,color.Red,color.Green, color.Blue );
                    break;
                case "RED":
                    Debug.WriteLine("Case: red " + recognizeText.ToUpper());
                    color = this._red;
                    ChangeColor(this._userPrim,color.Red,color.Green, color.Blue );
                    break;
                case "GREEN":
                    Debug.WriteLine("Case: green " + recognizeText.ToUpper());
                    color = this._green;
                    ChangeColor(this._userPrim,color.Red,color.Green, color.Blue );
                    break;
                case "BLUE":
                    Debug.WriteLine("Case: blue " + recognizeText.ToUpper());
                    color = this._blue;
                    ChangeColor(this._userPrim,color.Red,color.Green, color.Blue );
                    break;
                case "YELLOW":
                    Debug.WriteLine("Case: yellow " + recognizeText.ToUpper());
                    color = this._yellow;
                    ChangeColor(this._userPrim,color.Red,color.Green, color.Blue );
                    break;
                case "CYAN":
                    Debug.WriteLine("Case: cyan " + recognizeText.ToUpper());
                    color = this._cyan;
                    ChangeColor(this._userPrim,color.Red,color.Green, color.Blue );
                    break;
                case "MAGENTA":
                    Debug.WriteLine("Case: magenta " + recognizeText.ToUpper());
                    color = this._magenta;
                    ChangeColor(this._userPrim,color.Red,color.Green, color.Blue );
                    break;
                default:
                    break;
            }
                
        }

        /// <summary>
        /// Used to determine what the user is intending as far as selecting the size of the object.
        /// X and Y plane increases are determined by looking at which ever plane has a difference > 0.
        /// This means that the user would like the object to increase or decrease in size along the axis
        /// where the difference between the two points(hands) is > 0. 
        /// </summary>
        /// <param name="skeleton"></param>
        public void InterpretGestureSize(SkeletonData skeleton)
        {
            // used to slow down the number of times that the program cycles through this method and 
            // updates SL. 
            if (!CycleCountCheck())
                return;

            // convert the data feed from the kinect to as better format. 
            double leftHandX = double.Parse(String.Format("{0:F2}", skeleton.Joints[JointID.HandLeft].Position.X));
            double rightHandX = double.Parse(String.Format("{0:F2}", skeleton.Joints[JointID.HandRight].Position.X));

            double leftHandY = double.Parse(String.Format("{0:F2}", skeleton.Joints[JointID.HandLeft].Position.Y));
            double rightHandY = double.Parse(String.Format("{0:F2}", skeleton.Joints[JointID.HandRight].Position.Y));

            double leftHandZ = double.Parse(String.Format("{0:F2}", skeleton.Joints[JointID.HandLeft].Position.Z));
            double rightHandZ = double.Parse(String.Format("{0:F2}", skeleton.Joints[JointID.HandRight].Position.Z));
            
            // left hand on top or right hand on top makes no difference. 
            double xtoSL = Math.Abs(double.Parse(String.Format("{0:F2}",rightHandX - leftHandX)));
            double ytoSL = Math.Abs(double.Parse(String.Format("{0:F2}",rightHandY - leftHandY)));
            double ztoSL = Math.Abs(double.Parse(String.Format("{0:F2}",rightHandZ - leftHandZ)));
            // determine which currently has the max difference, thus the user intends to change this axis. 
            String currentMax = MaxOfXYZ(xtoSL,ytoSL,ztoSL);

            Debug.WriteLine("X: " + xtoSL + " Y: " + ytoSL + " Z: " + ztoSL + " Max: " + currentMax);

            // communicate the correct size change to SL and update the model prim object in the program. 
            // increment the prim in .4 meter amounts + and -
            double stepAmmount = .4;

            if (currentMax.Equals("x"))
            {
                if (DecideSize(xtoSL).Equals("down"))
                {
                    ChangeSize(this._userPrim,
                        this._userPrim.PrimSizeX -= stepAmmount
                        , this._userPrim.PrimSizeY
                        , this._userPrim.PrimSizeZ);
                }
                if (DecideSize(xtoSL).Equals("up"))
                {
                    ChangeSize(this._userPrim,
                        this._userPrim.PrimSizeX += stepAmmount
                        , this._userPrim.PrimSizeY
                        , this._userPrim.PrimSizeZ);
                }
            }
            if (currentMax.Equals("y"))
            {
                if (DecideSize(ytoSL).Equals("down"))
                {
                    ChangeSize(this._userPrim,
                        this._userPrim.PrimSizeX
                        , this._userPrim.PrimSizeY -= stepAmmount
                        , this._userPrim.PrimSizeZ);
                }
                if (DecideSize(ytoSL).Equals("up"))
                {
                    ChangeSize(this._userPrim,
                        this._userPrim.PrimSizeX
                        , this._userPrim.PrimSizeY += stepAmmount
                        , this._userPrim.PrimSizeZ);
                }
            }
            if (currentMax.Equals("z"))
            {
                if (DecideSize(ztoSL).Equals("down"))
                {
                    ChangeSize(this._userPrim,
                        this._userPrim.PrimSizeX
                        , this._userPrim.PrimSizeY
                        , this._userPrim.PrimSizeZ -= stepAmmount
                        );
                }
                if (DecideSize(ztoSL).Equals("up"))
                {
                    ChangeSize(this._userPrim,
                        this._userPrim.PrimSizeX
                        , this._userPrim.PrimSizeY
                        , this._userPrim.PrimSizeZ += stepAmmount
                        );
                }
            }
        }

        /// <summary>
        /// Helper method to determine which axis has the greater difference.
        /// Thus the user is indicting the desire to change this axis. 
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        /// <returns></returns>
        public String MaxOfXYZ(double x, double y, double z)
        {
            if (x>y && x>z)
            {
                return "x";
            }
            if (y>x && y>z)
            {
                return "y";
            }
            if (z>x && z>y)
            {
                return "z";
            }

            return "";
        }

        /// <summary>
        /// Helper method to determine dead zone of the kinect. 
        /// If the users hands are greater than this amount or closer than
        /// this other amount then movement, else do nothing. 
        /// </summary>
        /// <param name="diffrence"></param>
        /// <returns></returns>
        public String DecideSize(double diffrence)
        {
            if (diffrence < .25 )
            {
                return "down";
            }
            if (diffrence >.35)
            {
                return "up";
            }

            return "none";
        }

        /// <summary>
        /// Helper method used to reduce the perceived checking of this gesture by the 
        /// kinect runtime. Runtime is normally 30fps so cycle count to 30 sets the check at 1/sec
        /// </summary>
        /// <returns></returns>
        public bool CycleCountCheck()
        {
            this.cycleCount++;
            if (this.cycleCount > 30)
            {
                cycleCount = 0;
                return true;
            }

            return false;
        }

        /// <summary>
        /// If the game state is in shape mode then this method determines if the prim 
        /// needs to change depending on user desire. 
        /// </summary>
        /// <param name="confidence"></param>
        /// <param name="recognizeText"></param>
        public void InterpretGestureShape(double confidence, String recognizeText)
        {
           
            switch (recognizeText.ToUpper())
            {
                case "BOX":
                    Debug.WriteLine("Case: box " + recognizeText.ToUpper());
                    ChangeShape(this._userPrim, this._primShapes.ElementAt(0));
                    break;
                case "CYLINDER":                    
                    Debug.WriteLine("Case: cylinder " + recognizeText.ToUpper());     
                    ChangeShape(this._userPrim, this._primShapes.ElementAt(1));
                    break;
                case "PRISM":                    
                    Debug.WriteLine("Case: prism " + recognizeText.ToUpper());
                    ChangeShape(this._userPrim, this._primShapes.ElementAt(2));
                    break;
                case "SPHERE":                    
                    Debug.WriteLine("Case: sphere " + recognizeText.ToUpper());
                    ChangeShape(this._userPrim, this._primShapes.ElementAt(3));
                    break;
                case "TORUS":                    
                    Debug.WriteLine("Case: torus " + recognizeText.ToUpper());
                    ChangeShape(this._userPrim, this._primShapes.ElementAt(4));
                    break;
                case "RING":                   
                    Debug.WriteLine("Case: ring " + recognizeText.ToUpper());
                    ChangeShape(this._userPrim, this._primShapes.ElementAt(5));
                    break;
                case "TUBE":                    
                    Debug.WriteLine("Case: tube " + recognizeText.ToUpper());
                    ChangeShape(this._userPrim, this._primShapes.ElementAt(6));
                    break;
                default:                    
                    break;
            }
        }

        /// <summary>
        ///  Not implemented 
        /// </summary>
        public void InterpretGestureRotation()
        {

        }

        /// <summary>
        /// Event handler for the Rotation Timer object, any thing in this method is set to occur at
        /// intervals specified by the RotationTimer object. 
        /// </summary>
        /// <param name="source"></param>
        /// <param name="args"></param>
        public void RotationTimerHandler(object source, EventArgs args)
        {
            // update both the prim and its representation in SL          
            _randomReq.ChangeRotationSL(this._gamePrim.PrimRotationX +=10
                , this._gamePrim.PrimRotationY +=20
                , this._gamePrim.PrimRotationZ += 30);
            // mimic the above prim in its rotation. 
            ChangeRotation(this._userPrim, this._gamePrim.PrimRotationX,
                this._gamePrim.PrimRotationY, this._gamePrim.PrimRotationZ);
        }

    }
    
}
