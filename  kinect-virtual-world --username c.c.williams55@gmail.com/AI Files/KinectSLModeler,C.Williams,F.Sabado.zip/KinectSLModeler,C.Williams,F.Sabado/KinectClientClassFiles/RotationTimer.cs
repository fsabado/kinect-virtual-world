﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;

namespace WpfApplication_KinectProjectToPHPandSL
{
    /// <summary>
    /// Christian Williams 
    /// Uark 010537189
    /// ccw005@uark.edu
    /// 
    /// This class establishes a timer event that will be used by the Model game. 
    /// 
    /// </summary>
    class RotationTimer
    {
        private Timer _rotationTimer;

        public event EventHandler RotateTime;

        public delegate void EventHandler(object sender, EventArgs e);

        public RotationTimer()
        {
            this._rotationTimer = new Timer();
            this._rotationTimer.Elapsed += OnTimeInterval;
            this._rotationTimer.Interval = 3000;
            this._rotationTimer.Enabled = true;
        }

        /// <summary>
        /// When called this method toggles the timer to
        /// be on or off. 
        /// </summary>
        public void ToggleTimer()
        {
            if(this._rotationTimer.Enabled == true)
                this._rotationTimer.Enabled = false;
            else
                this._rotationTimer.Enabled = true;
        }       

        /// <summary>
        /// Establish the event method to be called by Elapsed event. 
        /// </summary>
        /// <param name="source"></param>
        /// <param name="args"></param>
        private void OnTimeInterval(object source, EventArgs args)
        {
            if (RotateTime != null)
            {
                // notify any event handlers wired to this event. 
                RotateTime(source, args);
            }
        }

    }
}
